document.write('<!DOCTYPE html>\
<html>\
\
<head>\
  <meta charset="utf-8">\
  <meta http-equiv="X-UA-Compatible" content="IE=edge">\
  <title></title>\
  <link rel="stylesheet" href="css/reset.css">\
  <link rel="stylesheet" href="css/grid.css">\
  <link rel="stylesheet" href="css/style.css">\
  <script src="js/script.js" type="text/javascript"></script>\
  <!-- jQuery -->\
  <script src="http://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="\
  crossorigin="anonymous"></script>\
</head>\
\
<body>\
  <div class="wrapper">\
    <div class="nav">\
      <a class="navTitle" href="" title=""><h1>Portfolio</h1></a>\
      <a class="navLinks" href="" title="">Home</a>\
      <a class="navLinks" href="" title="">Labs</a>\
      <a class="navLinks" href="" title="">About</a>\
      <a class="navLinks" href="" title="">Github</a>\
    </div>\
    <div class="contentAA">\
      <h2>Lab 1</h2>\
      <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>\
    </div>\
    <div class="contentAB">\
      <h2>Lab 2</h2>\
      <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>\
    </div>\
    <div class="contentAC">\
      <h2>Lab 3</h2>\
      <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>\
    </div>\
    <div class="contentAD">\
      <h2>Lab 4</h2>\
      <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>\
    </div>\
    <div class="contentBA">\
      <h2>Lab 5</h2>\
      <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>\
    </div>\
    <div class="contentBB">\
      <h2>Lab 4</h2>\
      <p>Maecenas sed diam eget risus varius blandit sit amet non magna.</p>\
    </div>\
  </div>\
</body>\
\
</html>\
');